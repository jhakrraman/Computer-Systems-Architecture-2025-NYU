import os
import argparse
import sys
import copy


def sign_extend(x, bits):
    mask = 1 << (bits - 1)
    return (x ^ mask) - mask


class InsMem(object):
    def __init__(self, name, ioDir):
        self.id = name
        with open(os.path.join(ioDir, "imem.txt")) as im:
            self.IMem = [data.strip() for data in im.readlines()]

    def _combine_4bytes(self, base):
        return ''.join(self.IMem[base:base + 4])

    def _reverse_bytes(self, b32):
        return ''.join([b32[i:i + 8] for i in range(0, 32, 8)][::-1])

    def readInstr(self, ReadAddress):
        if (ReadAddress + 3) < len(self.IMem):
            # Gather 4 bytes, then get little- and big-endian representations
            data_native = self._combine_4bytes(ReadAddress)
            data_swap = self._reverse_bytes(data_native)

            # Define allowable instruction opcodes
            opcode_list = {
                51, 19, 3, 35,
                99, 111, 103, 55,
                23, 127
            }
            # Extract opcode by masking the lowest 7 bits
            instr_native = int(data_native, 2) & 0x7F
            instr_swap = int(data_swap, 2) & 0x7F

            # Select based on valid opcode set
            if instr_native in opcode_list:
                result = data_native
            elif instr_swap in opcode_list:
                result = data_swap
            else:
                result = "00000000000000000000000000000000"
        else:
            result = "00000000000000000000000000000000"
        return result



class DataMem(object):
    def __init__(self, name, ioDir):
        self.id = name
        self.ioDir = ioDir
        self.MemSize = 1000
        with open(os.path.join(ioDir, "dmem.txt")) as dm:
            self.DMem = [data.strip() for data in dm.readlines()]
        self.DMem += ['0' * 8] * (self.MemSize - len(self.DMem))

    def readDataMem(self, ReadAddress):
        data_slice = self.DMem[ReadAddress:ReadAddress + 4]
        binary_str = ''.join(data_slice)
        numeric_val = int(binary_str, 2)
        return numeric_val

    def writeDataMem(self, Address, WriteData):
        bit_string = format(WriteData & 0xFFFFFFFF, "032b")
        for idx in range(4):
            chunk = bit_string[idx * 8 : (idx + 1) * 8]
            self.DMem[Address + idx] = chunk


    def outputDataMem(self):
        path = os.path.join(self.ioDir, "SS_DMEMResult.txt")
        with open(path, "w") as rp:
            rp.writelines([line + "\n" for line in self.DMem])



class RegisterFile(object):
    def __init__(self, ioDir):
        self.outputFile = os.path.join(ioDir, "SS_RFResult.txt")
        self.Registers = ['0' * 32 for _ in range(32)]

    def readRF(self, reg_addr):
        binary_val = self.Registers[reg_addr]
        # Converting binary string to integer
        reg_value = int(binary_val, 2)
        return reg_value

    def writeRF(self, reg_addr, data):
        if reg_addr > 0:
            # Restrict data to 32 bits
            bounded_data = data & 0xFFFFFFFF
            # Store as 32-character binary string
            self.Registers[reg_addr] = "{:032b}".format(bounded_data)


    def outputRF(self, cycle):
        op = [f"State of RF after executing cycle: {cycle}\n"]
        op += [val + "\n" for val in self.Registers]
        mode = "w" if cycle == 0 else "a"
        with open(self.outputFile, mode) as f:
            f.writelines(op)


class State(object):
    def __init__(self):
        self.IF = {"nop": False, "PC": 0}
        self.ID = {"nop": False, "Instr": 0}
        self.EX = {"nop": False, "Read_data1": 0, "Read_data2": 0, "Imm": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0, "is_I_type": False, "rd_mem": 0, 
                   "wrt_mem": 0, "alu_op": 0, "wrt_enable": 0}
        self.MEM = {"nop": False, "ALUresult": 0, "Store_data": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0, "rd_mem": 0, 
                   "wrt_mem": 0, "wrt_enable": 0}
        self.WB = {"nop": False, "Wrt_data": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0, "wrt_enable": 0}


class Core(object):
    def __init__(self, ioDir, imem, dmem):
        self.myRF = RegisterFile(ioDir)
        self.cycle = 0
        self.halted = False
        self.state = State()
        self.nextState = State()
        self.ext_imem = imem
        self.ext_dmem = dmem
        self.ioDir = ioDir
        self.instr_executed = 0  # dynamic instruction counter


class SingleStageCore(Core):
    def __init__(self, ioDir, imem, dmem):
        super().__init__(ioDir, imem, dmem)
        self.opFilePath = os.path.join(ioDir, "StateResult_SS.txt")

    def step(self):
        pc = self.state.IF["PC"]
        instr_bits = self.ext_imem.readInstr(pc)
        if instr_bits == "0" * 32:
            self.halted = True
            self.nextState.IF["nop"] = 1
            self.printState(self.nextState, self.cycle)
            return

        instr = int(instr_bits, 2)
        opcode = instr & 0x7F
        rd = (instr >> 7) & 0x1F
        funct3 = (instr >> 12) & 0x7
        rs1 = (instr >> 15) & 0x1F
        rs2 = (instr >> 20) & 0x1F
        funct7 = (instr >> 25) & 0x7F

        r1 = self.myRF.readRF(rs1)
        r2 = self.myRF.readRF(rs2)
        res = None
        next_pc = pc + 4

        imm_i = sign_extend(instr >> 20, 12)
        imm_s = sign_extend(((instr >> 7) & 0x1F) | (((instr >> 25) & 0x7F) << 5), 12)
        imm_b = (((instr >> 7) & 0x1) << 11) | (((instr >> 8) & 0xF) << 1) | (((instr >> 25) & 0x3F) << 5) | (((instr >> 31) & 0x1) << 12)
        imm_b = sign_extend(imm_b, 13)
        imm_j = (((instr >> 21) & 0x3FF) << 1) | (((instr >> 20) & 0x1) << 11) | (((instr >> 12) & 0xFF) << 12) | (((instr >> 31) & 0x1) << 20)
        imm_j = sign_extend(imm_j, 21)

        # ---------- Instruction Execution ----------
        if opcode == 0b0110011:
            # R-type: Arithmetic and logic ops
            if funct3 == 0 and funct7 == 0:
                result = r1 + r2
            elif funct3 == 0 and funct7 == 0b0100000:
                result = r1 - r2
            elif funct3 == 4:
                result = r1 ^ r2
            elif funct3 == 6:
                result = r1 | r2
            elif funct3 == 7:
                result = r1 & r2

        elif opcode == 0b0010011:
            # I-type: Immediate operations
            if funct3 == 0:
                result = r1 + imm_i
            elif funct3 == 4:
                result = r1 ^ imm_i
            elif funct3 == 6:
                result = r1 | imm_i
            elif funct3 == 7:
                result = r1 & imm_i

        elif opcode == 0b0000011:
            # LOAD instructions
            address = r1 + imm_i
            mem_val = self.ext_dmem.readDataMem(address)
            if funct3 == 2:  # LW
                result = mem_val
            elif funct3 == 0:  # LB
                result = mem_val & 0xFF
                if result & 0x80:
                    result |= 0xFFFFFF00
            elif funct3 == 1:  # LH
                result = mem_val & 0xFFFF
                if result & 0x8000:
                    result |= 0xFFFF0000
            else:
                result = mem_val

        elif opcode == 0b0100011:
            # SW: Store operation
            address = r1 + imm_s
            self.ext_dmem.writeDataMem(address, r2)

        elif opcode == 0b1100011:
            # BRANCH instructions
            branch_taken = False
            if funct3 == 0:
                branch_taken = r1 == r2
            elif funct3 == 1:
                branch_taken = r1 != r2
            elif funct3 == 4:
                branch_taken = r1 < r2
            elif funct3 == 5:
                branch_taken = r1 >= r2
            if branch_taken:
                next_pc = pc + imm_b

        elif opcode == 0b1101111:
            # JAL: Jump and Link
            result = pc + 4
            next_pc = pc + imm_j

        elif opcode == 0b1100111:
            # JALR: Jump and Link Register
            result = pc + 4
            next_pc = (r1 + imm_i) & ~1

        elif opcode == 0b1111111:
            # HALT: Program termination
            self.instr_executed += 1
            self.halted = True
            self.nextState.IF["nop"] = 1
            next_instruction = self.ext_imem.readInstr(pc + 4)
            self.nextState.IF["PC"] = pc + 4 if next_instruction != "0" * 32 else pc

        else:
            print(f"Unhandled instruction: {instr_bits}")
            sys.exit(1)


        # Writeback and PC update
        if res is not None and not self.halted:
            self.myRF.writeRF(rd, res)

        if not self.halted:
            self.nextState.IF["PC"] = next_pc

        if not self.halted and not self.nextState.IF["nop"]:
            self.instr_executed += 1  # dynamic instruction counter

        # Output state
        self.myRF.outputRF(self.cycle)
        self.printState(self.nextState, self.cycle)
        self.state = copy.deepcopy(self.nextState)
        self.cycle += 1

    def printState(self, state, cycle):
        lines = [
            "----------------------------------------------------------------------\n",
            f"State after executing cycle: {cycle}\n",
            f"IF.PC: {state.IF['PC']}\n",
            f"IF.nop: {bool(state.IF['nop'])}\n",
            "----------------------------------------------------------------------\n"
        ]
        mode = "w" if cycle == 0 else "a"
        with open(self.opFilePath, mode) as wf:
            wf.writelines(lines)


class PerfMe(object):
    def __init__(self, name, ioDir, stageCore):
        self.stageCore = stageCore
        self.opFilePath = os.path.join(ioDir, "PerformanceMetrics_Result.txt")

    def PrintPerf(self):
        cycles = self.stageCore.cycle + 1
        instrs = self.stageCore.instr_executed
        num_instr = max(instrs, 1)
        cpi = cycles / num_instr
        ipc = 1 / cpi
        with open(self.opFilePath, "w") as wf:
            wf.writelines([
                "Performance of Single Stage:\n",
                f"#Cycles -> {cycles}\n",
                f"#Instructions -> {num_instr}\n",
                f"CPI -> {cpi}\n",
                f"IPC -> {ipc}\n"
            ])


if __name__ == "__main__":
    #parse arguments for input file location
    parser = argparse.ArgumentParser(description='RV32I processor')
    parser.add_argument('--iodir', default="", type=str, help='Directory containing the input files.')
    args = parser.parse_args()

    ioDir = os.path.abspath(args.iodir)
    print("IO Directory:", ioDir)

    imem = InsMem("Imem", ioDir)
    dmem_ss = DataMem("SS", ioDir)
    dmem_fs = DataMem("FS", ioDir)
    
    ssCore = SingleStageCore(ioDir, imem, dmem_ss)
    #fsCore = FiveStageCore(ioDir, imem, dmem_fs)

    while True:
        ssCore.step()
        if ssCore.halted:
            ssCore.printState(ssCore.state, ssCore.cycle)
            break

    # dump SS data mem.
    dmem_ss.outputDataMem()

    ssPerf = PerfMe('SS', ioDir, ssCore)
    ssPerf.PrintPerf()
