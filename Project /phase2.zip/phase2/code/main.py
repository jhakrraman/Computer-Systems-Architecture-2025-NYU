import os
import argparse
import sys
import copy

class InstructionMemory(object):
    """
    Handles reading instructions from the input file.
    """
    def __init__(self, mem_name, io_dir):
        self.mem_id = mem_name
        
        # Load instruction memory from file
        try:
            with open(os.path.join(io_dir, "imem.txt"), "r") as im_file:
                self.instructions = [line.strip() for line in im_file.readlines()]
        except FileNotFoundError:
            print("Error: imem.txt not found in " + io_dir)
            sys.exit(1)

    def fetch_instruction(self, address):
        """
        Fetches a 32-bit instruction string starting at the given byte address.
        Instruction memory is byte-addressed, so we read 4 lines.
        """
        # Check bounds
        if address < len(self.instructions):
            instr_str = ""
            # Combine 4 bytes (lines) into one 32-bit string
            for offset in range(4):
                if address + offset < len(self.instructions):
                    instr_str += self.instructions[address + offset]
                else:
                    instr_str += "00000000" # Padding if partial
            return instr_str
        else:
            # Return NOP (all zeros) if out of bounds
            return "0" * 32

class DataMemory(object):
    """
    Handles data memory operations (Read/Write).
    """
    def __init__(self, mem_name, io_dir):
        self.mem_id = mem_name
        self.io_dir = io_dir
        self.capacity = 1000 # Memory depth
        
        # Load data memory
        try:
            with open(os.path.join(io_dir, "dmem.txt"), "r") as dm_file:
                self.memory = [line.strip() for line in dm_file.readlines()]
            
            # Fill remaining memory with zeros
            zeros_needed = self.capacity - len(self.memory)
            if zeros_needed > 0:
                self.memory.extend(['0' * 8] * zeros_needed)
                
        except FileNotFoundError:
            print("Error: dmem.txt not found in " + io_dir)
            sys.exit(1)

    def read_mem(self, address):
        """
        Reads a 32-bit word from memory at the given byte address.
        """
        # Construct 32-bit string from 4 bytes
        data_bits = ""
        for i in range(4):
            if address + i < len(self.memory):
                data_bits += self.memory[address + i]
            else:
                data_bits += "00000000"
        
        # Convert binary string to integer
        return int(data_bits, 2)

    def write_mem(self, address, data_val):
        """
        Writes a 32-bit integer data_val to memory at the given address.
        """
        # Convert int to 32-bit binary string
        bin_str = format(data_val if data_val >= 0 else (data_val + 2**32), '032b')
        
        # Write bytes
        for i in range(4):
            if address + i < len(self.memory):
                self.memory[address + i] = bin_str[i*8 : (i+1)*8]

    def dump_memory(self):
        """
        Writes the current state of data memory to a file.
        """
        out_path = os.path.join(self.io_dir, self.mem_id + "_DMEMResult.txt")
        with open(out_path, "w") as f:
            for byte_val in self.memory:
                f.write(str(byte_val) + "\n")

class RegisterFile(object):
    """
    Simulates the 32 general-purpose registers.
    """
    def __init__(self, io_path_prefix):
        # FIX: Use string concatenation instead of os.path.join here.
        # This ensures ".../SS_" + "RFResult.txt" becomes ".../SS_RFResult.txt"
        # instead of ".../SS_/RFResult.txt" (which would be a non-existent directory).
        self.out_file = io_path_prefix + "RFResult.txt"
        
        # Initialize registers x0-x31 to 32-bit zero strings
        self.regs = ['0' * 32] * 32

    def read_reg(self, reg_idx):
        """ Read register value as integer """
        return int(self.regs[reg_idx], 2)

    def write_reg(self, reg_idx, write_val):
        """ Write integer value to register """
        # x0 is always hardwired to 0
        if reg_idx == 0:
            return
            
        # Handle negative numbers (Two's complement)
        if write_val < 0:
            write_val += 2 ** 32
            
        # Format as 32-bit string
        bin_val = format(write_val, '032b')
        
        # Ensure only 32 bits are stored
        self.regs[reg_idx] = bin_val[-32:]

    def dump_rf(self, cycle_num):
        """ Append register state to output file """
        mode = "w" if cycle_num == 0 else "a"
        
        lines = [f"State of RF after executing cycle: {cycle_num}\n"]
        lines.extend([val + "\n" for val in self.regs])
        
        with open(self.out_file, mode) as f:
            f.writelines(lines)

class ProcessorState(object):
    """
    Holds the state of pipeline buffers.
    """
    def __init__(self):
        self.IF = {"nop": 0, "PC": 0}
        self.ID = {"nop": 1, "Instr": 0}
        self.EX = {"nop": 1, "Read_data1": 0, "Read_data2": 0, "Imm": 0, "Rs": 0, "Rt": 0, 
                   "Wrt_reg_addr": 0, "is_I_type": 0, "rd_mem": 0, "wrt_mem": 0, 
                   "alu_op": 0, "wrt_enable": 0}
        self.MEM = {"nop": 1, "ALUresult": 0, "Store_data": 0, "Rs": 0, "Rt": 0, 
                    "Wrt_reg_addr": 0, "rd_mem": 0, "wrt_mem": 0, "wrt_enable": 0}
        self.WB = {"nop": 1, "Wrt_data": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0, "wrt_enable": 0}

class Core(object):
    def __init__(self, io_path_prefix, i_mem, d_mem):
        self.reg_file = RegisterFile(io_path_prefix)
        self.curr_cycle = 0
        self.is_halted = False
        self.current_state = ProcessorState()
        self.next_state = ProcessorState()
        self.imem = i_mem
        self.dmem = d_mem

class SingleCycleCore(Core):
    def __init__(self, io_dir, i_mem, d_mem):
        # We construct the path prefix manually here.
        # This creates a string like ".../code/SS_"
        super(SingleCycleCore, self).__init__(io_dir + "/SS_", i_mem, d_mem)
        self.state_out_path = os.path.join(io_dir, "StateResult_SS.txt")

    def cycle_step(self):
        # Fetch Instruction
        curr_pc = self.current_state.IF["PC"]
        instruction = self.imem.fetch_instruction(curr_pc)
        self.next_state.ID["Instr"] = instruction

        # Decode Fields
        # Instr structure: imm[11:0] | rs1 | funct3 | rd | opcode
        opcode = instruction[-7:]
        funct3 = instruction[-15:-12]
        funct7 = instruction[:-25] # top 7 bits
        
        rd = int(instruction[-12:-7], 2)
        rs1 = int(instruction[-20:-15], 2)
        rs2 = int(instruction[-25:-20], 2)

        self.next_state.EX["Wrt_reg_addr"] = rd
        self.next_state.EX["Rs"] = rs1
        self.next_state.EX["Rt"] = rs2

        # Read Operands
        r_data1 = self.reg_file.read_reg(rs1)
        r_data2 = self.reg_file.read_reg(rs2)
        
        self.next_state.EX["Read_data1"] = r_data1
        self.next_state.EX["Read_data2"] = r_data2

        alu_res = 0
        
        # --- EXECUTION LOGIC ---
        
        # R-Type Instructions (ADD, SUB, XOR, OR, AND)
        if opcode == '0110011':
            if funct7 == '0000000':
                if funct3 == '000': # ADD
                    alu_res = r_data1 + r_data2
                elif funct3 == '100': # XOR
                    alu_res = r_data1 ^ r_data2
                elif funct3 == '110': # OR
                    alu_res = r_data1 | r_data2
                elif funct3 == '111': # AND
                    alu_res = r_data1 & r_data2
            elif funct7 == '0100000':
                if funct3 == '000': # SUB
                    alu_res = r_data1 - r_data2
            
            self.next_state.MEM["ALUresult"] = alu_res
            self.reg_file.write_reg(rd, alu_res)

        # I-Type ALU Instructions (ADDI, XORI, ORI, ANDI)
        elif opcode == '0010011':
            # Sign-extend Immediate (12 bits)
            imm_val = int(instruction[0:12], 2)
            if instruction[0] == '1': # Check sign bit
                imm_val -= (1 << 12)
            
            self.next_state.EX["Imm"] = imm_val
            
            if funct3 == '000': # ADDI
                alu_res = r_data1 + imm_val
            elif funct3 == '100': # XORI
                alu_res = r_data1 ^ imm_val
            elif funct3 == '110': # ORI
                alu_res = r_data1 | imm_val
            elif funct3 == '111': # ANDI
                alu_res = r_data1 & imm_val
                
            self.next_state.MEM["ALUresult"] = alu_res
            self.reg_file.write_reg(rd, alu_res)

        # Load Instructions (LW, LB)
        # Supports funct3 '010' (LW) and '000' (LB)
        elif opcode == '0000011' and funct3 in ['000', '010']:
            imm_val = int(instruction[0:12], 2)
            if instruction[0] == '1': 
                imm_val -= (1 << 12)
            
            self.next_state.EX["Imm"] = imm_val
            alu_res = r_data1 + imm_val
            self.next_state.MEM["ALUresult"] = alu_res
            
            # Read from Data Memory
            mem_data = self.dmem.read_mem(alu_res)
            
            # Update WB state and Write Register
            self.next_state.WB["Wrt_data"] = mem_data
            self.reg_file.write_reg(rd, mem_data)

        # Store Instruction (SW)
        elif opcode == '0100011' and funct3 == '010':
            # Construct store immediate: imm[11:5] + imm[4:0]
            imm_str = instruction[0:7] + instruction[20:25]
            imm_val = int(imm_str, 2)
            if imm_str[0] == '1':
                imm_val -= (1 << 12)
            
            self.next_state.EX["Imm"] = imm_val
            alu_res = r_data1 + imm_val
            self.next_state.MEM["ALUresult"] = alu_res
            
            # Write to Data Memory
            self.dmem.write_mem(alu_res, r_data2)

        # Branch Instructions (BEQ, BNE)
        elif opcode == '1100011':
            # Construct branch immediate
            # bit 12 | bits 10:5 | bit 11 | bits 4:1
            imm_str = instruction[0] + instruction[24] + instruction[1:7] + instruction[20:24] + '0'
            imm_val = int(imm_str, 2)
            if imm_str[0] == '1':
                imm_val -= (1 << 13)
                
            self.next_state.EX["Imm"] = imm_val
            
            take_branch = False
            if funct3 == '000': # BEQ
                take_branch = (r_data1 == r_data2)
            elif funct3 == '001': # BNE
                take_branch = (r_data1 != r_data2)
                
            if take_branch:
                self.next_state.IF["PC"] += (imm_val - 4)

        # Jump (JAL)
        elif opcode == '1101111':
            # Construct JAL immediate
            # bit 20 | bits 10:1 | bit 11 | bits 19:12
            imm_str = instruction[0] + instruction[12:20] + instruction[11] + instruction[1:11] + '0'
            imm_val = int(imm_str, 2)
            if imm_str[0] == '1':
                imm_val -= (1 << 21)
            
            self.next_state.EX["Imm"] = imm_val
            
            # Save link address (PC+4)
            self.reg_file.write_reg(rd, curr_pc + 4)
            
            # Update PC
            self.next_state.IF["PC"] += (imm_val - 4)

        # HALT Instruction
        elif opcode == '1111111':
            self.next_state.IF["nop"] = 1

        else:
            print(f"Error: Instruction not supported. Opcode: {opcode}, Funct3: {funct3}")
            print(f"Full Instruction: {instruction}")
            sys.exit(1)

        # Update PC if not halted
        if not self.next_state.IF["nop"]:
            self.next_state.IF["PC"] += 4
        else:
            self.is_halted = True

        # Dump state
        self.reg_file.dump_rf(self.curr_cycle)
        self.log_state(self.next_state, self.curr_cycle)

        # Advance state
        self.current_state = copy.deepcopy(self.next_state)
        self.curr_cycle += 1

    def log_state(self, state, cycle_idx):
        """ Prints the core state to file """
        lines = [f"State after executing cycle: {cycle_idx}\n"]
        lines.append(f"IF.PC: {state.IF['PC']}\n")
        lines.append(f"IF.nop: {state.IF['nop']}\n")

        mode = "w" if cycle_idx == 0 else "a"
        with open(self.state_out_path, mode) as f:
            f.writelines(lines)


class FiveStageCore(Core):
    def __init__(self, io_dir, i_mem, d_mem):
        # We construct the path prefix manually here.
        # This creates a string like ".../code/FS_"
        super(FiveStageCore, self).__init__(io_dir + "/FS_", i_mem, d_mem)
        self.state_out_path = os.path.join(io_dir, "StateResult_FS.txt")

    def cycle_step(self):
        # Initialize control signals on first cycle
        if self.curr_cycle == 0:
            self.fwd_a = '00'
            self.fwd_b = '00'
            self.load_use_hazard = 0
            self.br_stall = 0
            self.is_branch = False # flag for bne/beq
            self.is_jump = False

        # --- WB STAGE ---
        if self.current_state.WB["nop"]:
            self.next_state.WB["Rs"] = 0
            self.next_state.WB["Rt"] = 0
            self.next_state.WB["Wrt_reg_addr"] = 0
            self.next_state.WB["wrt_enable"] = 0
        else:
            if self.current_state.WB["wrt_enable"]:
                self.reg_file.write_reg(self.current_state.WB["Wrt_reg_addr"], 
                                      self.current_state.WB["Wrt_data"])

        # --- MEM STAGE ---
        if self.current_state.MEM["nop"]:
            self.next_state.WB["nop"] = 1
        else:
            self.next_state.WB["nop"] = 0
            # Pass through signals
            self.next_state.WB["Rs"] = self.current_state.MEM["Rs"]
            self.next_state.WB["Rt"] = self.current_state.MEM["Rt"]
            self.next_state.WB["Wrt_reg_addr"] = self.current_state.MEM["Wrt_reg_addr"]
            self.next_state.WB["wrt_enable"] = self.current_state.MEM["wrt_enable"]
            
            # Handle Memory Access
            addr = self.current_state.MEM["ALUresult"]
            
            if self.current_state.MEM['rd_mem']:
                # Load: Read from Data Memory
                val = self.dmem.read_mem(addr)
                self.next_state.WB["Wrt_data"] = val
            else:
                # ALU Result pass-through
                self.next_state.WB["Wrt_data"] = addr
                
            if self.current_state.MEM["wrt_mem"]:
                # Store: Write to Data Memory
                w_data = self.current_state.MEM["Store_data"]
                self.dmem.write_mem(addr, w_data)

        # --- EX STAGE ---
        if self.current_state.EX["nop"]:
            self.next_state.MEM["nop"] = 1
        else:
            self.next_state.MEM["nop"] = 0
            # Pass controls to MEM
            self.next_state.MEM["Rs"] = self.current_state.EX["Rs"]
            self.next_state.MEM["Rt"] = self.current_state.EX["Rt"]
            self.next_state.MEM["Wrt_reg_addr"] = self.current_state.EX["Wrt_reg_addr"]
            self.next_state.MEM["wrt_enable"] = self.current_state.EX["wrt_enable"]
            self.next_state.MEM["rd_mem"] = self.current_state.EX["rd_mem"]
            self.next_state.MEM["wrt_mem"] = self.current_state.EX["wrt_mem"]
            self.next_state.MEM["Store_data"] = self.current_state.EX["Read_data2"]

            # ALU Logic & Forwarding
            op1 = self.current_state.EX["Read_data1"]
            op2 = self.current_state.EX["Read_data2"]

            # Select Forwarding inputs
            if self.load_use_hazard:
                self.load_use_hazard = 0
                # Specific logic for LW hazard forwarding cases
                if self.fwd_a == '10': op1 = self.current_state.WB["Wrt_data"]
                elif self.fwd_a == '01': op1 = self.reg_file.read_reg(self.current_state.EX["Rs"])
                
                if self.fwd_b == '10':
                    if self.current_state.EX["wrt_mem"]:
                        self.next_state.MEM["Store_data"] = self.current_state.WB["Wrt_data"]
                    else: op2 = self.current_state.WB["Wrt_data"]
                elif self.fwd_b == '01':
                    val = self.reg_file.read_reg(self.current_state.EX["Rt"])
                    if self.current_state.EX["wrt_mem"]:
                        self.next_state.MEM["Store_data"] = val
                    else: op2 = val
            else:
                # Standard RAW forwarding
                if self.fwd_a == '10': op1 = self.current_state.MEM["ALUresult"]
                elif self.fwd_a == '01': op1 = self.current_state.WB["Wrt_data"]

                if self.fwd_b == '10':
                    if self.current_state.EX["wrt_mem"]:
                        self.next_state.MEM["Store_data"] = self.current_state.MEM["ALUresult"]
                    else: op2 = self.current_state.MEM["ALUresult"]
                elif self.fwd_b == '01':
                    if self.current_state.EX["wrt_mem"]:
                        self.next_state.MEM["Store_data"] = self.current_state.WB["Wrt_data"]
                    else: op2 = self.current_state.WB["Wrt_data"]

            # Immediate handling
            if self.current_state.EX["is_I_type"]:
                op2 = self.current_state.EX["Imm"]

            # Execute Operation
            alu_ctl = self.current_state.EX["alu_op"]
            res = 0
            if alu_ctl == 'ADD': res = op1 + op2
            elif alu_ctl == 'SUB': res = op1 - op2
            elif alu_ctl == 'AND': res = op1 & op2
            elif alu_ctl == 'OR': res = op1 | op2
            elif alu_ctl == 'XOR': res = op1 ^ op2
            
            self.next_state.MEM["ALUresult"] = res

        # --- ID STAGE ---
        if self.current_state.ID["nop"]:
            self.next_state.EX["nop"] = 1
        else:
            self.next_state.EX["nop"] = 0
            instr = self.current_state.ID["Instr"]
            
            # Decode register addresses
            rd_addr = int(instr[-12:-7], 2)
            rs1_addr = int(instr[-20:-15], 2)
            rs2_addr = int(instr[-25:-20], 2)
            
            self.next_state.EX["Wrt_reg_addr"] = rd_addr
            self.next_state.EX["Rs"] = rs1_addr
            self.next_state.EX["Rt"] = rs2_addr

            # Read Registers
            self.next_state.EX["Read_data1"] = self.reg_file.read_reg(rs1_addr)
            self.next_state.EX["Read_data2"] = self.reg_file.read_reg(rs2_addr)

            # Hazard Detection (Data Hazards)
            self.fwd_a = '00'
            self.fwd_b = '00'
            
            # Check MEM stage dependency
            if self.next_state.MEM["wrt_enable"] and self.next_state.MEM["Wrt_reg_addr"] != 0:
                if self.next_state.MEM["Wrt_reg_addr"] == rs1_addr: self.fwd_a = '10'
                if self.next_state.MEM["Wrt_reg_addr"] == rs2_addr: self.fwd_b = '10'
            
            # Check WB stage dependency
            if self.next_state.WB["wrt_enable"] and self.next_state.WB["Wrt_reg_addr"] != 0:
                if self.next_state.WB["Wrt_reg_addr"] == rs1_addr: self.fwd_a = '01'
                if self.next_state.WB["Wrt_reg_addr"] == rs2_addr: self.fwd_b = '01'

            # Load-Use Hazard Detection
            self.load_use_hazard = 0
            if self.next_state.MEM["rd_mem"]:
                if self.next_state.MEM["Wrt_reg_addr"] in [rs1_addr, rs2_addr]:
                    self.load_use_hazard = 1

            # --- Control Unit Decode ---
            opcode = instr[-7:]
            funct3 = instr[-15:-12]
            funct7 = instr[:-25]

            # Defaults
            self.next_state.EX["is_I_type"] = 0
            self.next_state.EX["rd_mem"] = 0
            self.next_state.EX["wrt_mem"] = 0
            self.next_state.EX["wrt_enable"] = 0
            self.is_branch = False
            self.is_jump = False

            # R-Type
            if opcode == '0110011':
                self.next_state.EX["wrt_enable"] = 1
                if funct3 == '000':
                    self.next_state.EX["alu_op"] = 'SUB' if funct7 == '0100000' else 'ADD'
                elif funct3 == '100': self.next_state.EX["alu_op"] = 'XOR'
                elif funct3 == '110': self.next_state.EX["alu_op"] = 'OR'
                elif funct3 == '111': self.next_state.EX["alu_op"] = 'AND'

            # I-Type ALU
            elif opcode == '0010011':
                self.next_state.EX["wrt_enable"] = 1
                self.next_state.EX["is_I_type"] = 1
                
                # Immediate decoding
                imm = int(instr[1:12], 2)
                if instr[0] == '1': imm -= (1 << 11)
                self.next_state.EX["Imm"] = imm
                
                if funct3 == '000': self.next_state.EX["alu_op"] = 'ADD' # ADDI
                elif funct3 == '100': self.next_state.EX["alu_op"] = 'XOR'
                elif funct3 == '110': self.next_state.EX["alu_op"] = 'OR'
                elif funct3 == '111': self.next_state.EX["alu_op"] = 'AND'

            # Load (LW, LB)
            # Checks for Opcode 0000011 AND (funct3 is 000 OR 010)
            elif opcode == '0000011' and funct3 in ['000', '010']:
                self.next_state.EX["wrt_enable"] = 1
                self.next_state.EX["is_I_type"] = 1
                self.next_state.EX["rd_mem"] = 1
                self.next_state.EX["alu_op"] = 'ADD'
                
                imm = int(instr[1:12], 2)
                if instr[0] == '1': imm -= (1 << 11)
                self.next_state.EX["Imm"] = imm

            # Store (SW)
            elif opcode == '0100011' and funct3 == '010':
                self.next_state.EX["is_I_type"] = 1
                self.next_state.EX["wrt_mem"] = 1
                self.next_state.EX["alu_op"] = 'ADD'
                
                imm_str = instr[:-25] + instr[-12:-7]
                imm = int(imm_str, 2)
                if imm_str[0] == '1': imm -= (1 << 11)
                self.next_state.EX["Imm"] = imm

            # JAL
            elif opcode == '1101111':
                self.next_state.EX["wrt_enable"] = 1
                self.next_state.EX["alu_op"] = 'ADD'
                self.next_state.EX["Read_data1"] = 0
                self.next_state.EX["Read_data2"] = self.current_state.IF['PC']
                
                imm_str = instr[0] + instr[12:20] + instr[11] + instr[1:11] + '0'
                imm = int(imm_str, 2)
                if imm_str[0] == '1': imm -= (1 << 21)
                self.next_state.EX["Imm"] = imm
                
                self.is_jump = True
                self.br_stall = 1

            # Branch (BEQ, BNE)
            elif opcode == '1100011':
                self.next_state.EX["alu_op"] = 'BEQ' if funct3 == '000' else 'BNE'
                
                imm_str = instr[0] + instr[24] + instr[1:7] + instr[20:24] + '0'
                imm = int(imm_str, 2)
                if imm_str[0] == '1': imm -= (1 << 13)
                self.next_state.EX["Imm"] = imm
                
                self.is_branch = True

            # HALT
            elif opcode == '1111111':
                self.next_state.IF["nop"] = 1
                self.next_state.ID["nop"] = 1
            else:
                print(f"Error: Instruction not supported. Opcode: {opcode}")
                sys.exit(1)

            # Branch Resolution Logic
            if self.is_branch:
                # Forwarding for branch comparison
                val_a = self.next_state.EX["Read_data1"]
                val_b = self.next_state.EX["Read_data2"]
                
                if self.fwd_a == '10': val_a = self.next_state.MEM["ALUresult"]
                elif self.fwd_a == '01': val_a = self.next_state.WB["Wrt_data"]
                
                if self.fwd_b == '10': val_b = self.next_state.MEM["ALUresult"]
                elif self.fwd_b == '01': val_b = self.next_state.WB["Wrt_data"]

                should_branch = False
                if self.next_state.EX["alu_op"] == 'BEQ' and val_a == val_b: should_branch = True
                if self.next_state.EX["alu_op"] == 'BNE' and val_a != val_b: should_branch = True
                
                if should_branch:
                    self.br_stall = 1

        # --- IF STAGE ---
        if self.current_state.IF["nop"]:
            if not self.load_use_hazard:
                self.next_state.ID["nop"] = 1
        else:
            self.next_state.ID["Instr"] = self.imem.fetch_instruction(self.current_state.IF["PC"])
            # Stop if Halt found
            if self.next_state.ID["Instr"][-7:] == '1111111':
                self.next_state.IF["nop"] = 1
                self.next_state.ID["nop"] = 1
            else:
                self.next_state.IF["nop"] = 0
                self.next_state.ID["nop"] = 0

        # Stall Handling
        if self.load_use_hazard:
            # Stall Pipeline: IF and ID hold state, EX gets bubble
            if self.current_state.EX["nop"]:
                self.next_state.IF["nop"] = 0
                self.next_state.ID["nop"] = 0
                self.next_state.EX["nop"] = 0
            else:
                self.next_state.IF["nop"] = 1
                self.next_state.ID["nop"] = 1
                self.next_state.EX["nop"] = 1

        if self.is_branch:
            # Insert bubble in EX for branch delay
            self.is_branch = False
            self.next_state.EX["nop"] = 1

        if self.br_stall:
            # Branch Taken: Flush and Update PC
            self.br_stall = 0
            self.next_state.IF["nop"] = 0
            self.next_state.ID["nop"] = 1
            self.next_state.EX["nop"] = 1
            self.next_state.IF["PC"] += (self.next_state.EX["Imm"] - 4)
            
            if self.is_jump:
                self.is_jump = False
                self.next_state.EX["nop"] = 0
        else:
            if not self.next_state.IF["nop"]:
                self.next_state.IF["PC"] += 4

        # Halt Condition Check
        if (self.current_state.IF["nop"] and self.current_state.ID["nop"] and 
            self.current_state.EX["nop"] and self.current_state.MEM["nop"] and 
            self.current_state.WB["nop"]):
            self.is_halted = True

        # Dump State
        self.reg_file.dump_rf(self.curr_cycle)
        self.log_state(self.next_state, self.curr_cycle)

        self.current_state = copy.deepcopy(self.next_state)
        self.curr_cycle += 1

    def log_state(self, state, cycle_idx):
        sep = "-" * 70 + "\n"
        header = f"State after executing cycle: {cycle_idx}\n"
        
        lines = [sep, header, "\n"]
        for stage_name in ["IF", "ID", "EX", "MEM", "WB"]:
            stage_dict = getattr(state, stage_name)
            lines.extend([f"{stage_name}.{k}: {v}\n" for k, v in stage_dict.items()])
            lines.append("\n")

        mode = "w" if cycle_idx == 0 else "a"
        with open(self.state_out_path, mode) as f:
            f.writelines(lines)

class PerformanceMetrics(object):
    """
    Calculates and prints CPI and IPC metrics.
    """
    def __init__(self, core_name, io_dir, core_obj):
        self.name = core_name
        self.core = core_obj
        self.out_path = os.path.join(io_dir, "PerformanceMetrics_Result.txt")

    def report(self):
        # Calculate dynamic instruction count
        # Note: This is an approximation based on the provided logic
        # Ideally, we would count retired instructions
        pc_ptr = 0
        instr_count = 0
        while True:
            instr = self.core.imem.fetch_instruction(pc_ptr)
            if instr == '0' * 32: # NOP/End of memory
                instr_count = pc_ptr / 4
                break
            pc_ptr += 4
            
        if instr_count == 0: instr_count = 1 # Prevent DivByZero
        
        cpi = self.core.curr_cycle / instr_count
        ipc = 1 / cpi

        mode = "w" if self.name == 'SS' else "a"
        
        header = f"{'Single' if self.name == 'SS' else 'Five'} Stage Core Performance Metrics " + "-" * 20 + "\n"
        lines = [
            header,
            f"Number of cycles taken: {self.core.curr_cycle}\n",
            f"Cycles per instruction: {cpi:.6f}\n",
            f"Instructions per cycle: {ipc:.6f}\n",
            "\n"
        ]

        with open(self.out_path, mode) as f:
            f.writelines(lines)

if __name__ == "__main__":
    # Command Line Argument Parsing
    parser = argparse.ArgumentParser(description='RV32I Processor Simulator')
    parser.add_argument('--iodir', default="", type=str, help='Input/Output Directory')
    args = parser.parse_args()

    io_directory = os.path.abspath(args.iodir)
    print("Simulating with IO Directory:", io_directory)

    # Initialize Memory
    imem = InstructionMemory("Imem", io_directory)
    dmem_ss = DataMemory("SS", io_directory)
    dmem_fs = DataMemory("FS", io_directory)

    # Initialize Cores
    ss_core = SingleCycleCore(io_directory, imem, dmem_ss)
    fs_core = FiveStageCore(io_directory, imem, dmem_fs)

    # Main Simulation Loop
    while True:
        if not ss_core.is_halted:
            ss_core.cycle_step()

        if not fs_core.is_halted:
            fs_core.cycle_step()

        if ss_core.is_halted and fs_core.is_halted:
            break

    # Output Results
    dmem_ss.dump_memory()
    dmem_fs.dump_memory()

    perf_ss = PerformanceMetrics('SS', io_directory, ss_core)
    perf_fs = PerformanceMetrics('FS', io_directory, fs_core)
    
    perf_ss.report()
    perf_fs.report()